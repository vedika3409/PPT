﻿var app = angular.module('Bus', [])
app.controller('BusCtrl', ['$http', function ($http) {
    var self = this;
    self.items = [];
    self.addBusDetail = {};
    self.editBusDetail = {};
    self.response;
    self.searchBusdetail = {};

    //<!--    To display all routes-->
    var fetchBus = function () {
        return $http.get('http://localhost:55133/api/BusApi').then(
            function (response) {
                self.items = response.data;
            }, function (errResponse) {
                console.error('Error while fetching buses');
            });
    };
    fetchBus();



    self.fetchSpecificBus = function (id) {
        return $http.get('http://localhost:55133/api/BusApi/' + id).then(
            function (response) {
                self.editBusDetail = response.data;
                debugger;
                var data = $.param(self.editBusDetail);
            }, function (errResponse) {
                console.error('Error while fetching buses');
            });
    };


    //<!--      To add new Bus-->
    self.addBus = function () {

        //debugger;
        var data = $.param(self.addBusDetail);
        $http({
            method: 'post',
            url: 'http://localhost:55133/api/BusApi',
            data: data,
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' }
        })
         .then(function (response) {
             fetchBus();
             self.addBusDetail = {};
         });
    };


    self.updateBus = function (BusId) {

        var data = $.param(self.editBusDetail);
        $http({
            method: 'put',
            url: 'http://localhost:55133/api/BusApi/' + self.editBusDetail.BusId,
            data: data,
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' }
        }).then(function (response) {
            fetchBus();
            self.editBusDetail = {};
        })
    };


    self.deleteBus = function (BusId) {
        $http.delete('http://localhost:55133/api/BusApi/' + BusId).then(
            function (response) { fetchBus();});
    };

    self.searchBus = function (search) {
        return $http.get('http://localhost:55133/api/BusApi?search=' + search).then(
            function (response) {
                self.searchBusDetail = response.data;
            }, function (errResponse) {
                console.error('Error while fetching buses');
            });
    };


}]);