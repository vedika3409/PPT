﻿var app = angular.module('Passenger', [])
app.controller('PassengerCtrl', ['$http', function ($http) {
    var self = this;
    self.items = [];
    self.addPassengerDetail = {};
    self.editPassengerDetail = {};
    self.response;
    self.searchPassengerdetail = {};

    //<!--    To display all routes-->
    var fetchPassenger = function () {
        return $http.get('http://localhost:55133/api/Passenger/').then(
            function (response) {
                self.items = response.data;
            }, function (errResponse) {
                console.error('Error while fetching passengers');
            });
    };
    fetchPassenger();



    self.fetchSpecificPassenger = function (id) {
        return $http.get('http://localhost:55133/api/Passenger/' + id).then(
            function (response) {
                self.editPassengerDetail = response.data;
                //debugger;
                var data = $.param(self.editPassengerDetail);
            }, function (errResponse) {
                console.error('Error while fetching buses');
            });
    };


    //<!--      To add new Bus-->
    //self.addPassenger = function () {

    //    //debugger;
    //    var data = $.param(self.addPassengerDetail);
    //    $http({
    //        method: 'post',
    //        url: 'http://localhost:55133/api/Passenger/',
    //        data: data,
    //        headers: { 'Content-Type': 'application/x-www-form-urlencoded' }
    //    })
    //    .then(fetchPassenger())
    //    .then(function (response) {
    //        self.addPassengerDetail = {};
    //    });
    //};

    //self.updatePassenger = function (PassengerId) {

    //    var data = $.param(self.editPassengerDetail);
    //    $http({
    //        method: 'put',
    //        url: 'http://localhost:55133/api/Passenger/' + self.editPassengerDetail.PassengerId,
    //        data: data,
    //        headers: { 'Content-Type': 'application/x-www-form-urlencoded' }
    //    }).then(fetchPassenger()).then(function (response) {
    //        self.editPassengerDetail = {};
    //    })
    //};


    self.deletePassenger = function (PassengerId) {
        $http.delete('http://localhost:55133/api/Passenger/' + PassengerId).then(
            function (response) { fetchPassenger(); });
    };

    self.searchPassenger = function (search) {
        return $http.get('http://localhost:55133/api/Passenger?search=' + search).then(
            function (response) {
                self.searchPassengerDetail = response.data;
            }, function (errResponse) {
                console.error('Error while fetching passengers');
            });
    };
}]);