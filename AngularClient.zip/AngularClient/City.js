﻿var app = angular.module('City', [])
app.controller('CityCtrl', ['$http', function ($http) {
    var self = this;
    self.items = [];
    self.addCityDetail = {};
    self.editCityDetail = {};
    self.response;
    self.item = {};

    //<!--    To display all routes-->
    var fetchCity = function () {
        return $http.get('http://localhost:55133/api/CityAPI').then(
            function (response) {
                self.items = response.data;
            }, function (errResponse) {
                console.error('Error while fetching cities');
            });
    };
    fetchCity();

    //<!--      To add new City-->
    
    self.addCity = function ()
    {
        debugger;
        var data = $.param(self.addCityDetail);     //Converts the data from form to key - valuE PAIR
        $http(
            {
                method: 'post',
                url: 'http://localhost:55133/api/CityAPI',
                data: data,
                headers: { 'Content-Type': 'application/x-www-form-urlencoded' }  
        }
           )     
     
        .then(function (response)
        {
            fetchCity();
            self.addCityDetail = {};
        });
       
    };

    self.fetchSpecificCity = function (id) {
        return $http.get('http://localhost:55133/api/CityAPI/' + id).then(
            function (response) {
                self.editCityDetail = response.data;
                debugger;
                var data = $.param(self.editCityDetail);
            }, function (errResponse) {
                console.error('Error while fetching cities');
            });
    };
    // To update route name
    self.updateCity = function (CityId) {
        debugger;
        var data = $.param(self.editCityDetail);
        $http({
            method: 'put',
            url: 'http://localhost:55133/api/CityAPI/' + self.editCityDetail.CityId,
            data: data,
            headers: { 'Content-Type': "application/x-www-form-urlencoded" }
        }).then(function (response) {
            fetchCity();
            self.editCityDetail = {};
           
        })
        
    };

    self.searchCity = function (search) {
        return $http.get('http://localhost:55133/api/CityAPI?search=' + search).then(
            function (response) {
                self.searchCityDetail = response.data;

            }, function (errResponse) {
                console.error('Error while fetching cities');
            });
    };

    //$http.delete('http://localhost:55133/api/CityAPI/' + CityId).
    //       then(
    //       fetchCity()).then(function (response) {

    //       });

    //To delete Route
    self.deleteCity = function (CityId) {
        $http.delete('http://localhost:55133/api/CityAPI/' + CityId).
            then(
            function (response) { fetchCity();});
    };


}
]
 );
