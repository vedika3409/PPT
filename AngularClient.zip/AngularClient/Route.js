﻿var app = angular.module('BusApp', [])
app.controller('RouteCtrl', ['$http', function ($http) {
    var self = this;
    self.items = [];
    self.addRouteDetail = {};
    self.editRouteDetail = {};
    self.response;
    self.item = {};

    //<!--    To display all routes-->
    var fetchRoute = function () {
        return $http.get('http://localhost:55133/api/Route').then(
            function (response) {
                self.items = response.data;
            }, function (errResponse) {
                console.error('Error while fetching routes');
            });
    };
    fetchRoute();



    //self.searchRoute = function (search) {
    //    return $http.get('http://localhost:55133/api/Route?search=' + search).then(
    //        function (response) {
    //            self.searchRouteDetail = response.data;

    //        }, function (errResponse) {
    //            console.error('Error while fetching routes');
    //        });
    //};
    ////<!--      To add new City-->

    //self.addRoute = function () {
    //    //debugger;
    //    var data = $.param(self.addRouteDetail);     //Converts the data from form to key - valuE PAIR
    //    console.log(data);
    //    $http(
    //        {
    //            method: 'post',
    //            url: 'http://localhost:55133/api/Route',
    //            data: data,
    //            headers: { 'Content-Type': 'application/x-www-form-urlencoded' }
    //        }
    //       )
    //    .then(fetchRoute())
    //    .then(function (response) {
    //        self.addRouteDetail = {};
    //    });

    //};


    //self.fetchSpecificRoute = function (id) {
    //    return $http.get('http://localhost:55133/api/Route/' + id).then(
    //        function (response) {
    //            self.editRouteDetail = response.data;
    //            debugger;
    //            var data = $.param(self.editRouteDetail);
    //        }, function (errResponse) {
    //            console.error('Error while fetching routes');
    //        });
    //};
    //// To update route name
    //self.updateRoute = function (RouteId) {

    //    var data = $.param(self.editRouteDetail);
    //    $http({
    //        method: 'put',
    //        url: 'http://localhost:55133/api/Route/' + self.editRouteDetail.RouteId,
    //        data: data,
    //        headers: { 'Content-Type': "application/x-www-form-urlencoded" }
    //    }).then(fetchRoute()).then(function (response) {
    //        self.editRouteDetail = {};
    //    })
    //};


    ////To delete Route
    //debugger;
    //self.deleteRoute = function (RouteId) {
    //    $http.delete('http://localhost:55133/api/Route/' + RouteId).
    //        then(
    //        fetchRoute()).then(function (response) {

    //        });
    //};


}
]
 );
