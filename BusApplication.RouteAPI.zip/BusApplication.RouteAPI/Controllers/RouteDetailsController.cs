﻿using BusApplication.Core;
using BusApplication.Repository;
using System;
using System.Collections.Generic;
using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Http;
using System.Web.Http.Description;
using System.Web.Mvc;

namespace BusApplication.RouteAPI.Controllers
{
    public class RouteDetailsController : ApiController
    {
        
        private RouteRepository _routerepo = new RouteRepository();

        // GET api/RouteDetails
        public IQueryable<RouteDetail> GetRoutes()
        {
            
            return _routerepo.GetRoutes();
        }

        // GET api/Product/5
        [ResponseType(typeof(RouteDetail))]
        public IHttpActionResult GetRoutes(int id)
        {
            //Product product = db.Products.Find(id);
            //using repository
            RouteDetail route = _routerepo.FindById(Convert.ToInt32(id));
            if (route == null)
            {
                return NotFound();
            }

            return Ok(route);
        }

        // PUT api/Product/5
        public IHttpActionResult PutRoute(int id, RouteDetail route)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            if (id != route.RouteId)
            {
                return BadRequest();
            }

            //db.Entry(product).State = EntityState.Modified;

            try
            {
                //db.SaveChanges();
                //using repository
                _routerepo.Edit(route);
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!RouteExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return StatusCode(HttpStatusCode.NoContent);
        }

        // POST api/Product
        [ResponseType(typeof(RouteDetail))]
        public IHttpActionResult PostRoute(RouteDetail route)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            //db.Products.Add(product);
            //db.SaveChanges();

            //using repository
            _routerepo.Add(route);

            return CreatedAtRoute("DefaultApi", new { id = route.RouteId }, route);
        }

        // DELETE api/Product/5
        [ResponseType(typeof(RouteDetail))]
        public IHttpActionResult DeleteProduct(int id)
        {
            //Product product = db.Products.Find(id);

            //using repository
            RouteDetail route = _routerepo.FindById(Convert.ToInt32(id));
            if (route == null)
            {
                return NotFound();
            }

            //db.Products.Remove(product);
            //db.SaveChanges();

            //using repository
            _routerepo.Remove(id);
            return Ok(route);
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                //db.Dispose();
            }
            base.Dispose(disposing);
        }

        private bool RouteExists(int id)
        {
            RouteDetail route = _routerepo.FindById(Convert.ToInt32(id));
            if (route == null)
            {
                return false;
            }

            return true;
        }
    
	}
}