﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BusReservation.Core
{
    public class BusSeatBookingDetailsData
    {
        public int BusSeatBookingId { get; set; }
        public Nullable<int> BusSeatId { get; set; }
        public Nullable<int> StatusId { get; set; }
        public Nullable<int> RouteId { get; set; }
        public Nullable<System.DateTime> CreatedOn { get; set; }
        public Nullable<System.DateTime> UpdatedOn { get; set; }
        public Nullable<System.DateTime> DeletedOn { get; set; }
        public string CreatedBy { get; set; }
        public string UpdatedBy { get; set; }
        public string DeletedBy { get; set; }
        public string StatusName { get; set; }
    
    }
}
