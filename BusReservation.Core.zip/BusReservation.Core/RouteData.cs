﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BusReservation.Core
{
    public class RouteData
    {
        //public int RouteId { get; set; }
        //public DateTime CreatedOn { get; set; }
        //public DateTime UpdatedOn { get; set; }
        //public DateTime DeletedOn { get; set; }
        //public string CreatedBy { get; set; }
        //public string UpdatedBy { get; set; }
        //public string DeletedBy { get; set; }
        //public int DestinationCityId { get; set; }
        //public int SourceCityId { get; set; }
        public int RouteId { get; set; }
        public Nullable<System.DateTime> CreatedOn { get; set; }
        public Nullable<System.DateTime> UpdatedOn { get; set; }
        public Nullable<System.DateTime> DeletedOn { get; set; }
        public string CreatedBy { get; set; }
        public string UpdatedBy { get; set; }
        public string DeletedBy { get; set; }
        public Nullable<int> DestinationCityId { get; set; }
        public Nullable<int> SourceCityId { get; set; }
        public string SourceCity { get; set; }
        public string DestinationCity { get; set; }
        public Nullable<int> Distance { get; set; }
        public string CityName { get; set; }
    }
}
