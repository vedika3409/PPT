﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BusReservation.Core
{
    public class Fare
    {
        public int BusId { get; set; }
        public string BusName { get; set; }
        public int FacilityId { get; set; }
        public string FacilityName { get; set; }
        public double Above16 { get; set; }
        public double Below16 { get; set; }
        public double Below5 { get; set; }
        public int RouteId { get; set; }
        public string SourceCity { get; set; }
        public string DestinationCity { get; set; }
        public Nullable<int> Distance { get; set; }
    }
}
