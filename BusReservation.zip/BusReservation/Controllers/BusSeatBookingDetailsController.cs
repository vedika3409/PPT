﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using BusReservation.Repository;
using BusReservation.Core;
using System.Net;

namespace BusReservation.Controllers
{
   [Authorize(Roles = "Admin")]
    public class BusSeatBookingDetailsController : Controller
    {
         private BusSeatBookingDetailsRepository _repo = new BusSeatBookingDetailsRepository();
        // GET: /Bus/
        // GET: /RouteDetail/
         public ActionResult Index(string StatusName)
        {
            var rt = _repo.GetAllBookings();
             var sf= _repo.StatusSearch(StatusName);
            if (!String.IsNullOrEmpty(StatusName))
            {
                sf = sf.Where(y => y.StatusName.Contains(StatusName));
                return View(sf);

            }
            return View(rt);
        }

        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            //using repository
            Bus_Seats_Booking_Details booking = _repo.FindByBusBookingId(Convert.ToInt32(id));

            if (booking == null)
            {
                return HttpNotFound();
            }
            return View(booking);
        }

        public ActionResult Create()
        {
            //ViewBag.CategoryId = new SelectList(_repo.RouteDetails, "SourceCityId", "SourceCity", _repo.RouteData.SourceCityId);
            //ViewBag.SourceCityId = new SelectList(_repo.RouteDetails, "SourceCityId", "SourceCity");
            return View();
        }

        [HttpPost]
        public ActionResult Create(BusSeatBookingDetailsData booking)
        {
            if (ModelState.IsValid)
            {
                _repo.AddBooking(booking);

                return RedirectToAction("Index");
            }
            return View(booking);
        }

        // GET: /Product/Edit/5
        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            //using repository
            Bus_Seats_Booking_Details booking = _repo.FindByBusBookingId(Convert.ToInt32(id));
            if (booking == null)
            {
                return HttpNotFound();
            }
            return View(booking);
        }

        // POST: /Product/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit(Bus_Seats_Booking_Details booking)
        {
            if (ModelState.IsValid)
            {
                //using repository
                _repo.EditBooking(booking);
                return RedirectToAction("Index");
            }
            return View(booking);
        }

        // GET: /Product/Delete/5
        public ActionResult Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            //using repository
            Bus_Seats_Booking_Details booking = _repo.FindByBusBookingId(Convert.ToInt32(id));
            if (booking == null)
            {
                return HttpNotFound();
            }
            return View(booking);
        }

        // POST: /Product/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            //using repository
            _repo.Remove(id);
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                //db.Dispose();
            }
            base.Dispose(disposing);
        }
	}
}