﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using BusReservation.Repository;
using BusReservation.Core;
using System.Net;

namespace BusReservation.Controllers
{
    [Authorize]
    public class BusController : Controller
    {
        private BusDataRepository _repo = new BusDataRepository();
        // GET: /Bus/
        // GET: /RouteDetail/
        [AllowAnonymous]
        public ActionResult Index(string BusName)
        {
            var rt = _repo.GetAllBuses();
            if (!String.IsNullOrEmpty(BusName))
            {
                rt = rt.Where(y => y.BusName.Contains(BusName));

            }
            return View(rt);
        }
        [Authorize(Roles = "Admin")]
        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            //using repository
            Bus bus = _repo.FindByBusId(Convert.ToInt32(id));

            if (bus == null)
            {
                return HttpNotFound();
            }
            return View(bus);
        }

        [Authorize(Roles = "Admin")]
        public ActionResult Create()
        {
            //ViewBag.CategoryId = new SelectList(_repo.RouteDetails, "SourceCityId", "SourceCity", _repo.RouteData.SourceCityId);
            //ViewBag.SourceCityId = new SelectList(_repo.RouteDetails, "SourceCityId", "SourceCity");
            return View();
        }

        [HttpPost]
        [Authorize(Roles = "Admin")]
        public ActionResult Create(BusData bus)
        {
            if (ModelState.IsValid)
            {
                _repo.AddBus(bus);

                return RedirectToAction("Index");
            }
            return View(bus);
        }

        // GET: /Product/Edit/5
        [Authorize(Roles = "Admin")]
        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            //using repository
            Bus bus = _repo.FindByBusId(Convert.ToInt32(id));
            if (bus == null)
            {
                return HttpNotFound();
            }
            return View(bus);
        }

        // POST: /Product/Edit/5
        [HttpPost]
        [Authorize(Roles = "Admin")]
        [ValidateAntiForgeryToken]
        public ActionResult Edit(Bus bus)
        {
            if (ModelState.IsValid)
            {
                //using repository
                _repo.EditBus(bus);
                return RedirectToAction("Index");
            }
            return View(bus);
        }

        // GET: /Product/Delete/5
        [Authorize(Roles = "Admin")]
        public ActionResult Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            //using repository
            Bus bus = _repo.FindByBusId(Convert.ToInt32(id));
            if (bus == null)
            {
                return HttpNotFound();
            }
            return View(bus);
        }

        // POST: /Product/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        [Authorize(Roles = "Admin")]
        public ActionResult DeleteConfirmed(int id)
        {
            //using repository
            _repo.Remove(id);
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                //db.Dispose();
            }
            base.Dispose(disposing);
        }
	}
}