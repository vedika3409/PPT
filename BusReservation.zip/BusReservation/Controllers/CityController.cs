﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using BusReservation.Repository;
using System.Net;
using BusReservation.Core;


namespace BusReservation.Controllers
{
    [Authorize]
    public class CityController : Controller
    {
        private CityDataRepository _repo = new CityDataRepository();
        // 
        // GET: /City/
        [AllowAnonymous]
        public ActionResult Index(string CityName)
        {
            var rt = _repo.GetAllCities();
            if (!String.IsNullOrEmpty(CityName))
            {
                rt = rt.Where(y => y.CityName.Contains(CityName));

            }
            return View(rt);
        }
        [Authorize(Roles = "Admin")]
        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            //using repository
            City city = _repo.FindByCityId(Convert.ToInt32(id));

            if (city == null)
            {
                return HttpNotFound();
            }
            return View(city);
        }

        [Authorize(Roles = "Admin")]
        public ActionResult Create()
        {
            //ViewBag.CategoryId = new SelectList(_repo.RouteDetails, "SourceCityId", "SourceCity", _repo.RouteData.SourceCityId);
            //ViewBag.SourceCityId = new SelectList(_repo.RouteDetails, "SourceCityId", "SourceCity");
            return View();
        }

        [HttpPost]
        [Authorize(Roles = "Admin")]
        public ActionResult Create(CityData city)
        {
            if (ModelState.IsValid)
            {
                _repo.AddCity(city);

                return RedirectToAction("Index");
            }
            return View(city);
        }



        // GET: /Product/Edit/5
        [Authorize(Roles = "Admin")]
        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            //using repository
            City city = _repo.FindByCityId(Convert.ToInt32(id));
            if (city == null)
            {
                return HttpNotFound();
            }
            return View(city);
        }

        // POST: /Product/Edit/5
        [HttpPost]
        [Authorize(Roles = "Admin")]
        [ValidateAntiForgeryToken]
        public ActionResult Edit(City city)
        {
            if (ModelState.IsValid)
            {
                //using repository
                _repo.EditCity(city);
                return RedirectToAction("Index");
            }
            return View(city);
        }

        // GET: /Product/Delete/5
        [Authorize(Roles = "Admin")]
        public ActionResult Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            //using repository
            City city = _repo.FindByCityId(Convert.ToInt32(id));
            if (city == null)
            {
                return HttpNotFound();
            }
            return View(city);
        }

        // POST: /Product/Delete/5
        [HttpPost, ActionName("Delete")]
        [Authorize(Roles = "Admin")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            //using repository
            _repo.Remove(id);
            return RedirectToAction("Index");
        }
       
        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                //db.Dispose();
            }
            base.Dispose(disposing);
        }
	}
}
