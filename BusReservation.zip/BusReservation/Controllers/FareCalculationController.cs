﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using BusReservation.Core;
using BusReservation.Repository;
using System.Text;

namespace BusReservation.Controllers
{
    public class FareCalculationController : Controller
    {
        private FareCalculateRepository farerepo = new FareCalculateRepository();
        // GET: /FareCalculation/
        public ActionResult Index()
        {
            //var fac = farerepo.GetFacilities();
            //var dist = farerepo.GetDistance();
            var bid = farerepo.GetBusId();
            string busname = Request["busname"];
            string sourcecity = Request["sourcecity"];
            string destinationcity = Request["destinationcity"];
            //int age = Convert.ToInt32(Request["Age"].ToString());
            

            var d = farerepo.GetDistance(sourcecity, destinationcity);

            StringBuilder sb = new StringBuilder();
            sb.Append("<b>Source :</b> " + sourcecity + "<br/>");
            sb.Append("<b>Dest :</b> " + destinationcity + "<br/>");
            sb.Append("<b>Distance :</b> " + d + "<br/>");
            return Content(sb.ToString());
           // var scfilter =dist.Where(y => y.SourceCity.Equals(sourcecity) && y.DestinationCity.Equals(destinationcity));
           //var av= dist.
           // var abc = dist.Select(y => y.Distance.Contains(destinationcity));


            //if (!String.IsNullOrEmpty(CityName))
            //{
            //    cd = cd.Where(y => y.CityName.Contains(CityName));
            //}
           
        }
	}
}

//decimal principle = Convert.ToDecimal(Request["txtAmount"].ToString());
//    decimal rate = Convert.ToDecimal(Request["txtRate"].ToString());
//    int time = Convert.ToInt32(Request["txtYear"].ToString());
 
//    decimal simpleInteresrt = (principle*time*rate)/100;
 
//    StringBuilder sbInterest = new StringBuilder();
//    sbInterest.Append("<b>Amount :</b> " + principle+"<br/>");
//    sbInterest.Append("<b>Rate :</b> " + rate + "<br/>");
//    sbInterest.Append("<b>Time(year) :</b> " + time + "<br/>");
//    sbInterest.Append("<b>Interest :</b> " + simpleInteresrt);
//    return Content(sbInterest.ToString());