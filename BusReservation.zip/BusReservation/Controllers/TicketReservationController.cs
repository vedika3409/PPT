﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using BusReservation.Repository;
using BusReservation.Core;
using System.Net;

namespace BusReservation.Controllers
{
    [Authorize(Roles = "Admin")]
    public class TicketReservationController : Controller
    {
        private TicketReservationRepository _repo = new TicketReservationRepository();
        // GET: /Bus/
        // GET: /RouteDetail/
        public ActionResult Index(string TicketReserveId)
        {
            var rt = _repo.GetAllReservation();
            if (!String.IsNullOrEmpty(TicketReserveId))
            {
                //rt = rt.Where(y => y.TicketReserveId.Contains(TicketReserveId));

            }
            return View(rt);
        }

        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            //using repository
            Ticket_Reservation reservation = _repo.FindByTicketReserveId(Convert.ToInt32(id));

            if (reservation == null)
            {
                return HttpNotFound();
            }
            return View(reservation);
        }

        public ActionResult Create()
        {
            //ViewBag.CategoryId = new SelectList(_repo.RouteDetails, "SourceCityId", "SourceCity", _repo.RouteData.SourceCityId);
            //ViewBag.SourceCityId = new SelectList(_repo.RouteDetails, "SourceCityId", "SourceCity");
            return View();
        }

        [HttpPost]
        public ActionResult Create(TicketReservationData reservation)
        {
            if (ModelState.IsValid)
            {
                _repo.AddReservation(reservation);

                return RedirectToAction("Index");
            }
            return View(reservation);
        }

        // GET: /Product/Edit/5
        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            //using repository
            Ticket_Reservation reservation = _repo.FindByTicketReserveId(Convert.ToInt32(id));
            if (reservation == null)
            {
                return HttpNotFound();
            }
            return View(reservation);
        }

        // POST: /Product/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit(Ticket_Reservation reservation)
        {
            if (ModelState.IsValid)
            {
                //using repository
                _repo.EditReservation(reservation);
                return RedirectToAction("Index");
            }
            return View(reservation);
        }

        // GET: /Product/Delete/5
        public ActionResult Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            //using repository
            Ticket_Reservation reservation = _repo.FindByTicketReserveId(Convert.ToInt32(id));
            if (reservation == null)
            {
                return HttpNotFound();
            }
            return View(reservation);
        }

        // POST: /Product/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            //using repository
            _repo.Remove(id);
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                //db.Dispose();
            }
            base.Dispose(disposing);
        }
	}
}