﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using BusReservation.Core;
using BusReservation.Repository;

namespace BusReservation.Controllers
{
    [Authorize]
    public class TicketDetailController : Controller
    {

        private TicketDetailRepository _repo = new TicketDetailRepository();
        [AllowAnonymous]
        public ActionResult Index(string BusName)
        {
            var rt = _repo.GetAllTickets();
            if (!String.IsNullOrEmpty(BusName))
            {
                //rt = rt.Where(y => y.BusName.Contains(BusName));

            }
            return View(rt);
        }

        [Authorize(Roles = "Admin")]
        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            //using repository
            TicketDetail1 ticket = _repo.FindByTicketId(Convert.ToInt32(id));

            if (ticket == null)
            {
                return HttpNotFound();
            }
            return View(ticket);
        }

        [Authorize(Roles = "Admin")]
        public ActionResult Create()
        {
            //ViewBag.CategoryId = new SelectList(_repo.RouteDetails, "SourceCityId", "SourceCity", _repo.RouteData.SourceCityId);
            //ViewBag.SourceCityId = new SelectList(_repo.RouteDetails, "SourceCityId", "SourceCity");
            return View();
        }

        [HttpPost]
        [Authorize(Roles = "Admin")]
        public ActionResult Create(TicketDetailData ticket)
        {
            if (ModelState.IsValid)
            {
                _repo.AddTicket(ticket);

                return RedirectToAction("Index");
            }
            return View(ticket);
        }

        // GET: /Product/Edit/5
        [Authorize(Roles = "Admin")]
        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            //using repository
            TicketDetail1 ticket = _repo.FindByTicketId(Convert.ToInt32(id));
            if (ticket == null)
            {
                return HttpNotFound();
            }
            return View(ticket);
        }

        // POST: /Product/Edit/5
        [HttpPost]
        [Authorize(Roles = "Admin")]
        [ValidateAntiForgeryToken]
        public ActionResult Edit(TicketDetail1 ticket)
        {
            if (ModelState.IsValid)
            {
                //using repository
                _repo.EditTicket(ticket);
                return RedirectToAction("Index");
            }
            return View(ticket);
        }

        // GET: /Product/Delete/5
        [Authorize(Roles = "Admin")]
        public ActionResult Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            //using repository
            TicketDetail1 ticket = _repo.FindByTicketId(Convert.ToInt32(id));
            if (ticket == null)
            {
                return HttpNotFound();
            }
            return View(ticket);
        }

        // POST: /Product/Delete/5
        [HttpPost, ActionName("Delete")]
        [Authorize(Roles = "Admin")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            //using repository
            _repo.Remove(id);
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                //db.Dispose();
            }
            base.Dispose(disposing);
        }
	}
}