﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using BusReservation.Repository;
using BusReservation.Core;
using System.Net;


namespace BusReservation.Controllers
{
    [Authorize]
    public class RouteDetailController : Controller
    {
        private RouteDataRepository _repo = new RouteDataRepository();

        // GET: /RouteDetail/
        [AllowAnonymous]
        public ActionResult Index(string SourceCity)
        {
            var rt = _repo.GetAllRoutes();
            var rf = _repo.RouteSearch(SourceCity);
           if (!String.IsNullOrEmpty(SourceCity))     
            {
                rf = rf.Where(y => y.SourceCity.Contains(SourceCity));
                return View(rf);

            }
            return View(rt);
        }

        [Authorize(Roles = "Admin")]
        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            //using repository
            RouteDetail route = _repo.FindByRouteId(Convert.ToInt32(id));

            if (route == null)
            {
                return HttpNotFound();
            }
            return View(route);
        }

        [Authorize(Roles = "Admin")]
        public ActionResult Create()
        {
            //ViewBag.CategoryId = new SelectList(_repo.RouteDetails, "SourceCityId", "SourceCity", _repo.RouteData.SourceCityId);
            //ViewBag.SourceCityId = new SelectList(_repo.RouteDetails, "SourceCityId", "SourceCity");
            return View();
        }

        [HttpPost]
        [Authorize(Roles = "Admin")]
        public ActionResult Create(RouteData route)
        {
            if (ModelState.IsValid)
            {
                _repo.AddRoute(route);
               
                return RedirectToAction("Index");
             }
            return View(route);
        }

        // GET: /Product/Edit/5
        [Authorize(Roles = "Admin")]
        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            //using repository
            RouteDetail route = _repo.FindByRouteId(Convert.ToInt32(id));
            if (route == null)
            {
                return HttpNotFound();
            }
            return View(route);
        }

        // POST: /Product/Edit/5

        [HttpPost]
        [Authorize(Roles = "Admin")]
        [ValidateAntiForgeryToken]
        public ActionResult Edit(RouteDetail route)
        {
            if (ModelState.IsValid)
            {
                //using repository
                _repo.EditRoute(route);
                return RedirectToAction("Index");
            }
            return View(route);
        }

        // GET: /Product/Delete/5
        [Authorize(Roles = "Admin")]
        public ActionResult Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
           //using repository
            RouteDetail route = _repo.FindByRouteId(Convert.ToInt32(id));
            if (route == null)
            {
                return HttpNotFound();
            }
            return View(route);
        }

        // POST: /Product/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        [Authorize(Roles = "Admin")]
        public ActionResult DeleteConfirmed(int id)
        {
             //using repository
            _repo.Remove(id);
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                //db.Dispose();
            }
            base.Dispose(disposing);
        }

	}
}
