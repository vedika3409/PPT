﻿app.factory('busService', function ($http) {
    var searchData;
    var reserved;
    var selectedBus;
    return {
        searchData:searchData,
        reserved: reserved,
        selectedBus:selectedBus,
        apiData: function (url, data, method) {
            var postData= $http({
                url: url,
                data: data,
                method: method,
                headers: { 'Content-Type': 'application/json' }
            })
            .then(
             function successCallback(response) {
                 return response;
             },
             function errorCallback(response) {
                 return response;
             }
            );

            return postData;
        },
        apiParamData: function (url, data, method) {
            var postData = $http({
                url: url+"?"+data,

                method: method,
                headers: { 'Content-Type': 'application/x-www-form-urlencoded' }
            })
            .then(
             function successCallback(response) {
                 return response;
             },
             function errorCallback(response) {
                 return response;
             }
            );

            return postData;
        }
    }
});