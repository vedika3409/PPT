﻿app.controller('seatCtrl', function (busService, $location) {
    var self = this;
    console.log(busService.selectedBus);
    self.busId = busService.selectedBus;
    self.reserved = busService.reserved;
    self.Seats = new Array(30);
    console.log(self.Seats.length);
    for (var i = 0;i<self.Seats.length;i++) {
       self.Seats[i] = (i+1);
   }
    console.log(self.Seats);
    busService.apiParamData("http://localhost:55133/api/SeatAPI", $.param({ BusId: self.busId }),"GET").then(function (response) {
        console.log(response.data);
        busService.reserved = response.data;
        self.reserved = response.data;
    });

});