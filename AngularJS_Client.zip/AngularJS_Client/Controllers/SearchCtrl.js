﻿app.controller('searchCtrl', function (busService,$location,$filter) {
    var self = this;
    self.searchData = busService.searchData;
   // busService.getData("", "", "");
    self.fetchSearch = function (data) {
        data.filtersearch = $filter('date')(data.filtersearch, 'EEEE', '+0530');
        busService.apiParamData("http://localhost:55133/api/BusSearchAPI", $.param(data), 'GET')
		.then(function (response) {
           busService.searchData = response.data;
            console.log(response.data);
            $location.path("/businfo");
        });
    }
    self.selectBus = function (busid) {
        busService.selectedBus = busid;
    }
});