﻿var app = angular.module('busApp', ['ngRoute']);


app.config(function ($routeProvider) {
    $routeProvider
    .when("/", {
        templateUrl: "Views/Search.html",
        controller:"searchCtrl"
    })
    .when("/businfo", {
        templateUrl: "Views/BusInfo.html",
        controller: "searchCtrl"
    })
    .when("/seatlayout", {
        templateUrl: "Views/SeatLayout.html",
        controller: "seatCtrl"
    })
    .otherwise({
        redirectTo:"/"
    });

});