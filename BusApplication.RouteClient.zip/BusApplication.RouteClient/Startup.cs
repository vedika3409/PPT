﻿using Microsoft.Owin;
using Owin;

[assembly: OwinStartupAttribute(typeof(BusApplication.RouteClient.Startup))]
namespace BusApplication.RouteClient
{
    public partial class Startup
    {
        public void Configuration(IAppBuilder app)
        {
            ConfigureAuth(app);
        }
    }
}
