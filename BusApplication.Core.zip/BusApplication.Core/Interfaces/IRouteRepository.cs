﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BusApplication.Core.Interfaces
{
    public interface IRouteRepository
    {
            IQueryable<RouteDetail> GetRoutes();
            RouteDetail FindById(int Id);
            void Add(RouteDetail p);
            void Edit(RouteDetail p);
            void Remove(int Id);       
    }
}
