﻿using BusApplication.Core;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;
using System.Web;
using System.Web.Mvc;
using System.Web.Script.Serialization;

namespace BusApplication.WebAPI2.Controllers
{
    public class Route1Controller : Controller
    {
        HttpClient client;

        string url = "http://localhost:54420/API/RouteDetails";

        public Route1Controller()
        {
            client = new HttpClient();
            client.BaseAddress = new Uri(url);
            client.DefaultRequestHeaders.Accept.Clear();
            client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
        }

        // GET: /Route1/
        public async Task<ActionResult> Index()
        {
            HttpResponseMessage responseMessage = await client.GetAsync(url);
            if (responseMessage.IsSuccessStatusCode)
            {
                var responseData = responseMessage.Content.ReadAsStringAsync().Result;

                var Route1 = JsonConvert.DeserializeObject<List<RouteDetail>>(responseData);

                return View(Route1);
            }
            return View("Error");
        }

        //[HttpGet]    
        //public async Task<ActionResult> Index(string searchroute)
        //{
        //    if (searchroute == null)
        //    {
        //    HttpResponseMessage responseMessage = await client.GetAsync(url);
        //    if (responseMessage.IsSuccessStatusCode)
        //    {
        //        var responseData = responseMessage.Content.ReadAsStringAsync().Result;

        //        var Route1 = JsonConvert.DeserializeObject<List<RouteDetail>>(responseData);

        //        return View(Route1);
        //    }
        //    return View("Error");
        //    }
        //}

        public async Task<ActionResult> Search(int searchroute)
        {
            HttpResponseMessage responseMessage = await client.GetAsync(url + "/" + searchroute);
            if (responseMessage.IsSuccessStatusCode)
            {
                var responseData = responseMessage.Content.ReadAsStringAsync().Result;

                var route1 = JsonConvert.DeserializeObject<List<RouteDetail>>(responseData);

                return View(route1);
            }
            return View("Error");

        }
        //
        // GET: /Route1/Details/5
        public async Task<ActionResult> Details(int id)
        {
            HttpResponseMessage responseMessage = await client.GetAsync(url + "/" + id);
            if (responseMessage.IsSuccessStatusCode)
            {
                var responseData = responseMessage.Content.ReadAsStringAsync().Result;

                var route1 = JsonConvert.DeserializeObject<RouteDetail>(responseData);

                return View(route1);
            }
            return View("Error");
        }

        //
        // GET: /Route1/Create
        public ActionResult Create()
        {
            //ViewBag.SourceCityId = new SelectList(_repo.Categories, "CategoryId", "CategoryName");
            return View(new RouteDetail());
        }

        //This method is calling Web API Post method
        [HttpPost]
        public async Task<ActionResult> Create(RouteDetail route1)
        {

            //HttpResponseMessage responseMessage = await client.PostAsJsonAsync(url, route);
            HttpResponseMessage responseMessage = await client.PostAsync(url, new StringContent(
   new JavaScriptSerializer().Serialize(route1), Encoding.UTF8, "application/json"));
            if (responseMessage.IsSuccessStatusCode)
            {
                return RedirectToAction("Index");
            }
            return RedirectToAction("Error");
        }

        //
        //GET: /Route1/Edit/5
        public async Task<ActionResult> Edit(int id)
        {
            HttpResponseMessage responseMessage = await client.GetAsync(url + "/" + id);
            if (responseMessage.IsSuccessStatusCode)
            {
                var responseData = responseMessage.Content.ReadAsStringAsync().Result;

                var route = JsonConvert.DeserializeObject<RouteDetail>(responseData);

                return View(route);
            }
            return View("Error");
        }

        //
        //This method is calling Web API PUT Method
        [HttpPost]
        public async Task<ActionResult> Edit(int id, RouteDetail route1)
        {
            route1.UpdatedOn = DateTime.Now;
            HttpResponseMessage responseMessage = await client.PutAsync(url + "/" + id, new StringContent(
   new JavaScriptSerializer().Serialize(route1), Encoding.UTF8, "application/json"));
            if (responseMessage.IsSuccessStatusCode)
            {
                return RedirectToAction("Index");
            }
            return RedirectToAction("Error");
        }


        // GET: /Route1/Delete/5
        public async Task<ActionResult> Delete(int id)
        {
            HttpResponseMessage responseMessage = await client.GetAsync(url + "/" + id);
            if (responseMessage.IsSuccessStatusCode)
            {
                var responseData = responseMessage.Content.ReadAsStringAsync().Result;

                var Route1 = JsonConvert.DeserializeObject<RouteDetail>(responseData);

                return View(Route1);
            }
            return View("Error");
        }

        //
        // POST: /Route1/Delete/5
        [HttpPost]
        public async Task<ActionResult> Delete(int id, RouteDetail route1)
        {

            HttpResponseMessage responseMessage = await client.DeleteAsync(url + "/" + id);
            if (responseMessage.IsSuccessStatusCode)
            {
                return RedirectToAction("Index");
            }
            return RedirectToAction("Error");
        }
    }
}
