﻿using BusReservation.Core;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace BusReservation.Repository
{
    public class RouteDataRepository
    {
        private BusAppDBEntities busAppDB = new BusAppDBEntities();

        public IEnumerable<RouteData> GetAllRoutes()
        {

            IQueryable<RouteData> routeList = from route in busAppDB.RouteDetails
                            select new RouteData { RouteId = route.RouteId, CreatedOn = route.CreatedOn, UpdatedOn = route.UpdatedOn, DeletedOn = route.DeletedOn, CreatedBy = route.CreatedBy, UpdatedBy = route.UpdatedBy, DeletedBy = route.DeletedBy, DestinationCityId = route.DestinationCityId, SourceCityId = route.SourceCityId, SourceCity=route.SourceCity, DestinationCity=route.DestinationCity, Distance= route.Distance };

            return routeList.ToList();
        }

        public IEnumerable<RouteData> RouteSearch(string SourceCity) 
        {
            IQueryable<RouteData> routes = from r in busAppDB.RouteDetails
											where r.City.CityName==SourceCity                                         
                                           select new RouteData { RouteId = r.RouteId, CreatedOn = r.CreatedOn, UpdatedOn = r.UpdatedOn,DeletedOn = r.DeletedOn, CreatedBy = r.CreatedBy, UpdatedBy = r.UpdatedBy,DestinationCityId = r.DestinationCityId, SourceCityId = r.SourceCityId,  SourceCity = r.City.CityName,DestinationCity=r.DestinationCity, Distance= r.Distance };
            return routes.ToList();

        }	
        public void AddRoute(RouteData addRouteData)
        {
            RouteDetail addRoute = new RouteDetail();
            addRoute.CreatedOn = System.DateTime.Now;
            addRoute.CreatedBy = addRouteData.CreatedBy;
            addRoute.SourceCityId = addRouteData.SourceCityId;
            addRoute.DestinationCityId = addRouteData.DestinationCityId;
            addRoute.SourceCity = addRouteData.SourceCity;
            addRoute.DestinationCity = addRouteData.DestinationCity;
            //ViewBag.CategoryId = new SelectList(busAppDB.Cities, "SourceCityId", "CityName");
            busAppDB.RouteDetails.Add(addRoute);
            busAppDB.SaveChanges();
        }

        public RouteDetail FindByRouteId(int Id)
        {

            var result = (from route in busAppDB.RouteDetails
                          where route.RouteId == Id
                          select route).FirstOrDefault();
            return result;
        }

        public void EditRoute(RouteDetail route)
        {
            route.UpdatedOn = System.DateTime.Now;
            busAppDB.Entry(route).State = System.Data.Entity.EntityState.Modified;
            busAppDB.SaveChanges();
        }
        

        public void Remove(int Id)
        {
            RouteDetail r = busAppDB.RouteDetails.Find(Id);
            busAppDB.RouteDetails.Remove(r);
            busAppDB.SaveChanges();
        }
       
    }
}

