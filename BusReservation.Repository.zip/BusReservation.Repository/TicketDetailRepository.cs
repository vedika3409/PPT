﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BusReservation.Core;

namespace BusReservation.Repository
{
    public class TicketDetailRepository
    {
        private BusAppDBEntities busAppDB = new BusAppDBEntities();
        public IEnumerable<TicketDetailData> GetAllTickets()
        {

            IQueryable<TicketDetailData> ticketList = from ticket in busAppDB.TicketDetails1
                                                      select new TicketDetailData { TicketId = ticket.TicketId, UserId = ticket.UserId,TravelDate=ticket.TravelDate, CreatedOn = ticket.CreatedOn, UpdatedOn = ticket.UpdatedOn, DeletedOn = ticket.DeletedOn, CreatedBy = ticket.CreatedBy, UpdatedBy = ticket.UpdatedBy, DeletedBy = ticket.DeletedBy};

            return ticketList.ToList();
        }


        public void AddTicket(TicketDetailData addTicketData)
        {
            TicketDetail1 addTicket = new TicketDetail1();
            addTicket.CreatedOn = System.DateTime.Now;
            addTicket.CreatedBy = addTicketData.CreatedBy;
            addTicket.UserId = addTicketData.UserId;
            addTicket.TravelDate = addTicketData.TravelDate;
            //ViewBag.CategoryId = new SelectList(busAppDB.RouteDetails, "SourceCityId", "SourceCity", busAppDB.RouteDetails.SourceCityId);
            busAppDB.TicketDetails1.Add(addTicket);
            busAppDB.SaveChanges();
        }

        public TicketDetail1 FindByTicketId(int Id)
        {

            var result = (from ticket in busAppDB.TicketDetails1
                          where ticket.TicketId == Id
                          select ticket).FirstOrDefault();
            return result;
        }

        public void EditTicket(TicketDetail1 ticket)
        {
            ticket.UpdatedOn = System.DateTime.Now;
            busAppDB.Entry(ticket).State = System.Data.Entity.EntityState.Modified;
            busAppDB.SaveChanges();
        }


        public void Remove(int Id)
        {
            TicketDetail1 t = busAppDB.TicketDetails1.Find(Id);
            busAppDB.TicketDetails1.Remove(t);
            busAppDB.SaveChanges();
        }
    }
}
