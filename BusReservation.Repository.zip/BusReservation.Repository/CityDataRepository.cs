﻿using BusReservation.Core;
using System.Data.Entity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BusReservation.Repository
{
    public class CityDataRepository
    {
        private BusAppDBEntities busAppDB = new BusAppDBEntities();

        public IEnumerable<CityData> GetAllCities()
        {
            IQueryable<CityData> cityList = from city in busAppDB.Cities
                                        select new CityData {CityId=city.CityId, CityName = city.CityName, CreatedBy = city.CreatedBy,UpdatedBy=city.UpdatedBy,DeletedBy=city.DeletedBy,CreatedOn=city.CreatedOn,UpdatedOn=city.UpdatedOn,DeletedOn=city.DeletedOn };
            return cityList.ToList();
        }

        public void AddCity(CityData addCityData)
        {
            City addCity = new City();
            addCity.CreatedOn = System.DateTime.Now;
            addCity.CityName = addCityData.CityName;
            busAppDB.Cities.Add(addCity);
            busAppDB.SaveChanges();
        }

        public City FindByCityId(int Id)
        {

            var result = (from city in busAppDB.Cities
                          where city.CityId == Id
                          select city).FirstOrDefault();
            return result;
        }

        public void EditCity(City city)
        {
            city.UpdatedOn = System.DateTime.Now;
            busAppDB.Entry(city).State = System.Data.Entity.EntityState.Modified;
            busAppDB.SaveChanges();
        }


        public void Remove(int Id)
        {
            City c = busAppDB.Cities.Find(Id);
            busAppDB.Cities.Remove(c);
            busAppDB.SaveChanges();
        }

        //public void EditCity(CityData updcityData)
        //{
        //    City currentCityData = busAppDB.Cities.First(city => city.CityId == updcityData.CityId);
        //    currentCityData.CityName = updcityData.CityName;
        //    busAppDB.Entry(currentCityData).State = EntityState.Modified;
        //    busAppDB.SaveChanges();
        //}

        //public void AddCity(CityData addcityData)
        //    {
        //        City addCity = new City();
        //        addCity.CityName = addcityData.CityName;
        //        busAppDB.Cities.Add(addCity);
        //        busAppDB.SaveChanges();
        //    }


        //public void Remove(int delCityId)
        //{
        //    City delCity = busAppDB.Cities.First(city => city.CityId == delCityId);
        //    busAppDB.Cities.Remove(delCity);
        //    busAppDB.SaveChanges();
        //}


    }
}
