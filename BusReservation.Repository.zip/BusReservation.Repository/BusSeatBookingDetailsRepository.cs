﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BusReservation.Core;

namespace BusReservation.Repository
{
    public class BusSeatBookingDetailsRepository
    {
        private BusAppDBEntities busAppDB = new BusAppDBEntities();

        public IEnumerable<BusSeatBookingDetailsData> GetAllBookings()
        {

            IQueryable<BusSeatBookingDetailsData> bookingList = from booking in busAppDB.Bus_Seats_Booking_Details
                                                                select new BusSeatBookingDetailsData { BusSeatBookingId = booking.BusSeatBookingId, BusSeatId = booking.BusSeatId,StatusId=booking.StatusId,RouteId=booking.RouteId ,CreatedOn = booking.CreatedOn, UpdatedOn = booking.UpdatedOn, DeletedOn = booking.DeletedOn, CreatedBy = booking.CreatedBy, UpdatedBy = booking.UpdatedBy, DeletedBy = booking.DeletedBy };

            return bookingList.ToList();
        }

        public IEnumerable<BusSeatBookingDetailsData> StatusSearch(string StatusName)
        {
            IQueryable<BusSeatBookingDetailsData> status = from booking in busAppDB.Bus_Seats_Booking_Details
                                                           where booking.StatusDetail.StatusName == StatusName
                                                           select new BusSeatBookingDetailsData { BusSeatBookingId = booking.BusSeatBookingId, BusSeatId = booking.BusSeatId, StatusId = booking.StatusDetail.StatusId, RouteId = booking.RouteId, CreatedOn = booking.CreatedOn, UpdatedOn = booking.UpdatedOn, DeletedOn = booking.DeletedOn, CreatedBy = booking.CreatedBy, UpdatedBy = booking.UpdatedBy, DeletedBy = booking.DeletedBy };
            return status.ToList();

        }	
        public void AddBooking(BusSeatBookingDetailsData addbookingData)
        {
            Bus_Seats_Booking_Details addbooking = new Bus_Seats_Booking_Details();
            addbooking.CreatedOn = System.DateTime.Now;
            addbooking.BusSeatBookingId = addbookingData.BusSeatBookingId;
            addbooking.StatusId = addbookingData.StatusId;
            addbooking.RouteId = addbookingData.RouteId;
            addbooking.BusSeatId = addbookingData.BusSeatId;
            addbooking.CreatedBy = addbookingData.CreatedBy;

            //ViewBag.CategoryId = new SelectList(busAppDB.RouteDetails, "SourceCityId", "SourceCity", busAppDB.RouteDetails.SourceCityId);
            busAppDB.Bus_Seats_Booking_Details.Add(addbooking);
            busAppDB.SaveChanges();
        }

        public Bus_Seats_Booking_Details FindByBusBookingId(int Id)
        {

            var result = (from bus in busAppDB.Bus_Seats_Booking_Details
                          where bus.BusSeatBookingId == Id
                          select bus).FirstOrDefault();
            return result;
        }

        public void EditBooking(Bus_Seats_Booking_Details bus)
        {
            bus.UpdatedOn = System.DateTime.Now;
            busAppDB.Entry(bus).State = System.Data.Entity.EntityState.Modified;
            busAppDB.SaveChanges();
        }


        public void Remove(int Id)
        {
            Bus_Seats_Booking_Details b = busAppDB.Bus_Seats_Booking_Details.Find(Id);
            busAppDB.Bus_Seats_Booking_Details.Remove(b);
            busAppDB.SaveChanges();
        }
         
    }
}
