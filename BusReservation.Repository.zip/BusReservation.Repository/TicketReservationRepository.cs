﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BusReservation.Core;

namespace BusReservation.Repository
{
    public class TicketReservationRepository
    {
        private BusAppDBEntities busAppDB = new BusAppDBEntities();
        public IEnumerable<TicketReservationData> GetAllReservation()
        {

            IQueryable<TicketReservationData> reservationList = from reservation in busAppDB.Ticket_Reservation
                                                                select new TicketReservationData { TicketReserveId = reservation.TicketReserveId, BusSeatBookingId = reservation.BusSeatBookingId,TicketId=reservation.TicketId,
                                                                   PassengerId= reservation.PassengerId,StatusId=reservation.StatusId,CreatedOn = reservation.CreatedOn, UpdatedOn = reservation.UpdatedOn, DeletedOn = reservation.DeletedOn, CreatedBy = reservation.CreatedBy, UpdatedBy = reservation.UpdatedBy, DeletedBy = reservation.DeletedBy};

            return reservationList.ToList();
        }


        public void AddReservation(TicketReservationData addReservationData)
        {
            Ticket_Reservation reservation = new Ticket_Reservation();
            reservation.CreatedOn = System.DateTime.Now;
            reservation.CreatedBy = addReservationData.CreatedBy;
            reservation.TicketReserveId = addReservationData.TicketReserveId;
            reservation.BusSeatBookingId = addReservationData.BusSeatBookingId;
            reservation.PassengerId = addReservationData.PassengerId;
            reservation.StatusId = addReservationData.StatusId;
            //ViewBag.CategoryId = new SelectList(busAppDB.RouteDetails, "SourceCityId", "SourceCity", busAppDB.RouteDetails.SourceCityId);
            busAppDB.Ticket_Reservation.Add(reservation);
            busAppDB.SaveChanges();
        }

        public Ticket_Reservation FindByTicketReserveId(int Id)
        {

            var result = (from reservation in busAppDB.Ticket_Reservation
                          where reservation.TicketReserveId == Id
                          select reservation).FirstOrDefault();
            return result;
        }

        public void EditReservation(Ticket_Reservation reservation)
        {
            reservation.UpdatedOn = System.DateTime.Now;
            busAppDB.Entry(reservation).State = System.Data.Entity.EntityState.Modified;
            busAppDB.SaveChanges();
        }


        public void Remove(int Id)
        {
            Ticket_Reservation r = busAppDB.Ticket_Reservation.Find(Id);
            busAppDB.Ticket_Reservation.Remove(r);
            busAppDB.SaveChanges();
        }
    }
}
