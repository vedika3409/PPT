﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BusReservation.Core;

namespace BusReservation.Repository
{
    public class BusDataRepository
    {
        private BusAppDBEntities busAppDB = new BusAppDBEntities();
        public IEnumerable<BusData> GetAllBuses()
        {

            IQueryable<BusData> busList = from bus in busAppDB.Buses
                                          select new BusData { BusId = bus.BusId,BusName=bus.BusName, CreatedOn = bus.CreatedOn, UpdatedOn = bus.UpdatedOn, DeletedOn = bus.DeletedOn, CreatedBy = bus.CreatedBy, UpdatedBy = bus.UpdatedBy, DeletedBy = bus.DeletedBy, FacilityId=bus.FacilityId};

            return busList.ToList();
        }


        public void AddBus(BusData addBusData)
        {
            Bus addBus = new Bus();
            addBus.CreatedOn = System.DateTime.Now;
            addBus.CreatedBy = addBusData.CreatedBy;
            addBus.BusName = addBusData.BusName;
           
            //ViewBag.CategoryId = new SelectList(busAppDB.RouteDetails, "SourceCityId", "SourceCity", busAppDB.RouteDetails.SourceCityId);
            busAppDB.Buses.Add(addBus);
            busAppDB.SaveChanges();
        }

        public Bus FindByBusId(int Id)
        {

            var result = (from bus in busAppDB.Buses
                          where bus.BusId == Id
                          select bus).FirstOrDefault();
            return result;
        }

        public void EditBus(Bus bus)
        {
            bus.UpdatedOn = System.DateTime.Now;
            busAppDB.Entry(bus).State = System.Data.Entity.EntityState.Modified;
            busAppDB.SaveChanges();
        }


        public void Remove(int Id)
        {
            Bus b = busAppDB.Buses.Find(Id);
            busAppDB.Buses.Remove(b);
            busAppDB.SaveChanges();
        }
       
    }
}
