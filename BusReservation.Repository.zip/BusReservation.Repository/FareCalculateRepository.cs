﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BusReservation.Core;

namespace BusReservation.Repository
{
    public class FareCalculateRepository
    {
        private BusAppDBEntities busAppDB = new BusAppDBEntities();
        //public IEnumerable<Fare> GetFacilities()
        //{
        //    IQueryable<Fare> facilityList = from facility in busAppDB.Facilities
        //                                    orderby facility.FacilityName
        //                                    select new Fare { FacilityId = facility.FacilityId, FacilityName=facility.FacilityName, Above16=(Convert.ToDouble(facility.Above16)), 
        //                                        Below16=(Convert.ToDouble(facility.Below16)), Below5=(Convert.ToDouble(facility.Below5))};
        //    return facilityList.ToList();
        //}

        public IEnumerable<Fare> GetAllRouteDetail()
        {
            IQueryable<Fare> routeList = from route in busAppDB.RouteDetails
                                         select new Fare { SourceCity = route.SourceCity, DestinationCity = route.DestinationCity, Distance =(Convert.ToInt32(route.Distance)) };
            return routeList.ToList();
        }
        public IEnumerable<Fare> GetBusId()
        {
            IQueryable<Fare> busList = from bus in busAppDB.Buses
                                       select new Fare { BusId = bus.BusId, BusName = bus.BusName };
            return busList.ToList();
        }
        public IEnumerable<Fare> GetDistance(string sc, string dest)
        {
            IQueryable<Fare> distList = from route in busAppDB.RouteDetails
                                       where route.SourceCity==sc && route.DestinationCity==dest
                                       select new Fare {Distance =route.Distance};
            return distList.ToList();
        }
    }
}


/*
using BusReservation.Core;
using System.Data.Entity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BusReservation.Repository
{
    public class CityDataRepository
    {
        private BusAppDBEntities busAppDB = new BusAppDBEntities();

        public IEnumerable<CityData> GetAllCities()
        {
            IQueryable<CityData> cityList = from city in busAppDB.Cities
                                            orderby city.CityName
                                            select new CityData { CityName = city.CityName };
            return cityList.ToList();
        }
         
        
    }
}

*/