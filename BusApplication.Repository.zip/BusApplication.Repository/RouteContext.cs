﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.Entity;
using BusApplication.Core;


namespace BusApplication.Repository
{
    public class RouteContext : DbContext
    {
        public RouteContext()
            :base("name=BusAppDBEntities")
        {
            this.Configuration.LazyLoadingEnabled = false;
            this.Configuration.ProxyCreationEnabled = false;
        }
        public DbSet<RouteDetail> RouteDetails { get; set; }
    }
}
//using MyApp.Core.DomainEntities;
//using System.Data.Entity;

//namespace MyApp.Repository
//{
//    public class MyAppContext : DbContext
//    {
//        public MyAppContext()
//            : base("name=MyAppConStr")
//        {

//        }

//        public DbSet<Product> Products { get; set; }
//    }
//}
