﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BusApplication.Core.Interfaces;
using BusApplication.Core;

namespace BusApplication.Repository
{
    public class RouteRepository :IRouteRepository
    {
        RouteContext context = new RouteContext();

        public IQueryable<RouteDetail> GetRoutes()
        {
            return context.RouteDetails;
        }

        public RouteDetail FindById(int Id)
        {
            var result = (from r in context.RouteDetails
                          where r.RouteId == Id
                          select r).FirstOrDefault();
            return result;
        }

        public void Add(RouteDetail p)
        {
            context.RouteDetails.Add(p);
            context.SaveChanges();
        }

        public void Edit(RouteDetail p)
        {
            context.Entry(p).State = System.Data.Entity.EntityState.Modified;
            context.SaveChanges();
        }

        public void Remove(int Id)
        {
            RouteDetail p = context.RouteDetails.Find(Id);
            context.RouteDetails.Remove(p);
            context.SaveChanges();
        }

    }
}
